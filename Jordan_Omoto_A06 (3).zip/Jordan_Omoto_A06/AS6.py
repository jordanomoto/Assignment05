# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
ToDoFile = "Todo.txt"
dicRow = {}
lstTable = []
strdata=""
class openfile:
    def txtfile():
        with open('Todo.txt', 'r') as lines:
            for line in lines:
                if ',' in line:
                    key, value = line.split(',')
                    dicRow[key] = (value)
        print(dicRow)

ToDoFile = open("Todo.txt", "a")
lstTable = [dicRow]

ToDoFile.close()
            
          
# Display a menu of choices to the user
def menu():
            print('''
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            ''')
    # Adds new item to the table
class options:
#prints items
    def Op1():
        print(lstTable)
#adds item to list
    def Op2():
        strTask = input("Enter Task Name:")
        strPriority = int(input("Enter priority level(1-10):"))
        dicRow[strTask]=strPriority
        lstTable.append(dicRow)
#removes item in list
    def Op3():
        print(lstTable)
        remove = input("Which item do you want to delete?:")
        if remove in dicRow:
            del dicRow[remove]
        else:
            print("not found")

#Main Program
openfile.txtfile()
while True:
    menu()
    strChoice = str(input("Which option would you like to perform? [1 to 4] - ")) 
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        print(lstTable)
    # Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        options.Op2()
    #Remove an existing item from the list/Table
    elif (strChoice == '3'):
        options.Op3
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        todo = open("Todo.txt", 'w')
        todo.write("\n")
        todo.write(lstTable)
        print("Data Saved")
        ToDo.close()
        continue
    elif (strChoice == '5'):
        input("Press enter to exit")
        break  # and Exit the program

